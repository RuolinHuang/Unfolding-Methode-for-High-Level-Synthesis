package scheduler;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


/***
 * Unfolding for a graph
 * 
 *	@param sg: input graph
 *  @param iteration: number of iteration the unfolding should do  
 *  @return graph after unfolding
 *
 */
// sg: input graph, iteration: number of iteration
public class Unfolding {
	public Graph Unfolding(final Graph sg, int iteration)
	{
		Graph g = sg.clone();	//clone the graph so that we can do modification

		for(int i = 1; i<iteration; i++)
		{
			Iterator<Node> graph_iterator = sg.iterator();
			for(int m = 0; m<sg.size(); m++)
			{
				Node ng = graph_iterator.next();	//node from original graph
				
				//create new node corresponding to node ng (name id + Iteration number, resource type)"  e.g. n1 --> n1_2
				Node node_new = new Node(ng.toString()+"_"+Integer.toString(i+1), ng.getRT());
						
				if(!ng.allSuccessors().isEmpty())	//not the last node
				{
					HashMap<Node, Integer> map_successor = ng.allSuccessors();
					Iterator<Node> iterator = map_successor.keySet().iterator();
					while(iterator.hasNext()==true)
					{
						Node successor = iterator.next();
						
						//create new node corresponding to successor (name id + Iteration number, resource type)"  e.g. n1 --> n1_2
						Node successor_new = new Node(successor.toString()+"_"+Integer.toString(i+1), successor.getRT());
						
						int distance = ng.getSuccWeight(successor);	//get label of edges
						if(distance==0)
							g.rlink(node_new, successor_new, distance);
						else
						{
							g.unlink(ng, successor);

							g.rlink(ng, successor_new, distance-1); //reduced weight
							g.rlink(node_new, successor, distance); //original weight
						}
								
					}
				}
				else
					g.add(node_new);		
			}

		}		
		return g;
	}
}